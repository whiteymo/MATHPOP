const express = require('express');
const path = require('path');
const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/users');
const profileRoutes = require('./routes/profile');
const gameRoutes = require('./routes/game');
const attendanceRoutes = require('./routes/attendance');
const dotenv = require('dotenv');

// Load environment variables from .env file
dotenv.config({ path: './config/config.env' });

const app = express();

// Middleware to parse JSON request bodies
app.use(express.json());

// Serve static files from the "frontend" directory (for landing page, login, registration, dashboards)
app.use(express.static(path.join(__dirname, '../frontend')));

// Serve game-specific static files from the "public" directory
app.use('/game', express.static(path.join(__dirname, 'public')));

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/profile', profileRoutes);
app.use('/api/game', gameRoutes);
app.use('/api/attendance', attendanceRoutes);

// Fallback route for handling 404 for API routes
app.use('/api/*', (req, res) => {
    res.status(404).json({ message: 'API route not found' });
});

// Serve the frontend pages
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend', 'index.html'));
});

app.get('/login.html', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend', 'login.html'));
});

app.get('/register.html', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend', 'register.html'));
});

app.get('/student-dashboard.html', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend', 'student-dashboard.html'));
});

app.get('/teacher-dashboard.html', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend', 'teacher-dashboard.html'));
});

// Serve the game main HTML file
app.get('/game', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
