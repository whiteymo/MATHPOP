const express = require('express');
const { poolPromise } = require('../config/db');
const authenticateToken = require('../middlewares/auth'); // JWT middleware

const router = express.Router();

// Save attendance (automatically when a student plays a game)
router.post('/record', authenticateToken, async (req, res) => {
    try {
        const pool = await poolPromise;
        const userId = req.user.id;
        const date = new Date();

        // Check if attendance is already recorded for today
        const existingAttendance = await pool.request()
            .input('userId', userId)
            .input('date', date.toISOString().split('T')[0]) // Check based on the date, ignoring time
            .query('SELECT * FROM Attendance WHERE userId = @userId AND CAST(attendanceDate AS DATE) = @date');

        if (existingAttendance.recordset.length === 0) {
            // Insert new attendance record
            await pool.request()
                .input('userId', userId)
                .input('attendanceDate', date)
                .query('INSERT INTO Attendance (userId, attendanceDate) VALUES (@userId, @attendanceDate)');

            res.status(201).json({ message: 'Attendance recorded successfully' });
        } else {
            res.status(200).json({ message: 'Attendance already recorded for today' });
        }
    } catch (err) {
        console.error('Database error:', err);
        res.status(500).json({ error: 'Database error occurred!' });
    }
});

// Get attendance records (for teacher/admin)
router.get('/', authenticateToken, async (req, res) => {
    try {
        const pool = await poolPromise;
        const result = await pool.request()
            .query('SELECT Users.id as studentId, Users.username, Attendance.attendanceDate FROM Attendance INNER JOIN Users ON Attendance.userId = Users.id ORDER BY Attendance.attendanceDate DESC');

        res.json(result.recordset);
    } catch (err) {
        console.error('Database error:', err);
        res.status(500).json({ error: 'Database error occurred!' });
    }
});

module.exports = router;
