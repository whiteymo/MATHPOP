const express = require('express');
const bcrypt = require('bcryptjs');
const { poolPromise } = require('../config/db');
const authenticateToken = require('../middlewares/auth');

const router = express.Router();

// Middleware to ensure the user is an admin (teacher role)
function ensureAdmin(req, res, next) {
    if (req.user.role !== 'teacher') {
        return res.status(403).json({ error: 'Access denied. Admins only.' });
    }
    next();
}

// Get all users (Admin only)
router.get('/', authenticateToken, ensureAdmin, async (req, res) => {
    try {
        const pool = await poolPromise;
        const result = await pool.request()
            .query('SELECT id, username, role FROM Users');

        res.json(result.recordset);
    } catch (err) {
        console.error('Database error:', err);
        res.status(500).json({ error: 'Database error occurred!' });
    }
});

// Check if username is available
router.get('/check-username', async (req, res) => {
    const { username } = req.query;

    try {
        const pool = await poolPromise;
        const result = await pool.request()
            .input('username', username)
            .query('SELECT * FROM Users WHERE username = @username');

        if (result.recordset.length > 0) {
            return res.json({ available: false });
        } else {
            return res.json({ available: true });
        }
    } catch (err) {
        console.error('Database error:', err);
        res.status(500).json({ error: 'Database error occurred!' });
    }
});

// Create a new user (Admin only)
router.post('/', authenticateToken, ensureAdmin, async (req, res) => {
    const { username, password, role } = req.body;

    // Ensure that the role is either 'student' or 'teacher'
    if (!['student', 'teacher'].includes(role)) {
        return res.status(400).json({ error: 'Invalid role provided.' });
    }

    try {
        const pool = await poolPromise;
        const transaction = pool.transaction();

        try {
            await transaction.begin();

            // Re-check if username already exists inside the transaction
            const userCheck = await transaction.request()
                .input('username', username)
                .query('SELECT * FROM Users WHERE username = @username');

            if (userCheck.recordset.length > 0) {
                await transaction.rollback();
                return res.status(400).json({ error: 'Username already taken.' });
            }

            // Hash the password
            const hashedPassword = await bcrypt.hash(password, 10);

            // Insert the new user into the database
            await transaction.request()
                .input('username', username)
                .input('password', hashedPassword)
                .input('role', role)
                .query('INSERT INTO Users (username, password, role) VALUES (@username, @password, @role)');

            await transaction.commit();

            res.status(201).json({ message: 'User registered successfully!' });
        } catch (err) {
            await transaction.rollback();
            console.error('Transaction error:', err);
            res.status(500).json({ error: 'Transaction error occurred!' });
        }
    } catch (err) {
        console.error('Database error:', err);
        res.status(500).json({ error: 'Database error occurred!' });
    }
});

// Update user information (Admin only)
router.put('/:id', authenticateToken, ensureAdmin, async (req, res) => {
    const { id } = req.params;
    const { username, password, role } = req.body;

    try {
        const pool = await poolPromise;

        let hashedPassword = null;
        if (password) {
            hashedPassword = await bcrypt.hash(password, 10);
        }

        // Update the user’s information
        const result = await pool.request()
            .input('id', id)
            .input('username', username)
            .input('role', role)
            .input('password', hashedPassword)
            .query(`
                UPDATE Users 
                SET 
                    username = @username, 
                    role = @role,
                    password = COALESCE(@password, password)
                WHERE id = @id
            `);

        if (result.rowsAffected[0] === 0) {
            return res.status(404).json({ error: 'User not found' });
        }

        res.json({ message: 'User updated successfully' });
    } catch (err) {
        console.error('Database error:', err);
        res.status(500).json({ error: 'Database error occurred!' });
    }
});

// Delete a user by ID (Admin only)
router.delete('/:id', authenticateToken, ensureAdmin, async (req, res) => {
    const { id } = req.params;

    try {
        const pool = await poolPromise;

        // Delete related scores first
        await pool.request()
            .input('id', id)
            .query('DELETE FROM Scores WHERE userId = @id');

        // Then delete the user
        const result = await pool.request()
            .input('id', id)
            .query('DELETE FROM Users WHERE id = @id');

        if (result.rowsAffected[0] === 0) {
            return res.status(404).json({ error: 'User not found' });
        }

        res.json({ message: 'User and related data deleted successfully' });
    } catch (err) {
        console.error('Database error:', err);
        res.status(500).json({ error: 'Database error occurred!' });
    }
});

module.exports = router;
