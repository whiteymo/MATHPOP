document.addEventListener('DOMContentLoaded', async function() {
    const token = localStorage.getItem('token');

    if (!token) {
        alert('You need to log in first.');
        window.location.href = '/login.html';
        return;
    }

    try {
        const response = await fetch('/api/profile', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.ok) {
            const profileData = await response.json();
            document.getElementById('profileInfo').innerHTML = `
                <p>Username: ${profileData.username}</p>
                <p>Role: ${profileData.role}</p>
            `;
        } else {
            localStorage.removeItem('token');
            alert('Session expired. Please log in again.');
            window.location.href = '/login.html';
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred. Please try again.');
    }
});

document.getElementById('logoutButton').addEventListener('click', function() {
    localStorage.removeItem('token');
    window.location.href = '/login.html';
});
