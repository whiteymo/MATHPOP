document.getElementById('registerForm').addEventListener('submit', async function(event) {
    event.preventDefault();

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const role = document.getElementById('role').value;

    // Check if the username is available before attempting to register
    const usernameFeedback = document.getElementById('usernameFeedback');
    let isUsernameAvailable = false;

    try {
        const usernameCheckResponse = await fetch(`/api/users/check-username?username=${encodeURIComponent(username)}`);
        const usernameData = await usernameCheckResponse.json();

        if (usernameData.available) {
            isUsernameAvailable = true;
            usernameFeedback.textContent = 'Username is available';
            usernameFeedback.style.color = 'green';
        } else {
            usernameFeedback.textContent = 'Username is not available';
            usernameFeedback.style.color = 'red';
            return; // Stop the registration process if the username is not available
        }
    } catch (error) {
        console.error('Error checking username:', error);
        usernameFeedback.textContent = 'Error checking username';
        usernameFeedback.style.color = 'red';
        return; // Stop the registration process if there was an error checking the username
    }

    if (isUsernameAvailable) {
        try {
            const response = await fetch('/api/auth/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, password, role })
            });

            if (response.ok) {
                alert('User registered successfully!');
                window.location.href = '/login.html'; // Redirect to login page
            } else {
                const errorData = await response.json();
                alert(`Registration failed: ${errorData.error}`);
            }
        } catch (error) {
            console.error('Error:', error);
            alert('An error occurred. Please try again.');
        }
    }
});

document.getElementById('username').addEventListener('input', async function() {
    const username = this.value;
    const feedbackElement = document.getElementById('usernameFeedback');

    try {
        const response = await fetch(`/api/users/check-username?username=${encodeURIComponent(username)}`);
        const data = await response.json();

        if (data.available) {
            feedbackElement.textContent = 'Username is available';
            feedbackElement.style.color = 'green';
        } else {
            feedbackElement.textContent = 'Username is not available';
            feedbackElement.style.color = 'red';
        }
    } catch (error) {
        console.error('Error checking username:', error);
        feedbackElement.textContent = 'Error checking username';
        feedbackElement.style.color = 'red';
    }
});
