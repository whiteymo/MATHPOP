const express = require('express');
const { poolPromise } = require('../config/db');
const authenticateToken = require('../middlewares/auth'); // JWT middleware

const router = express.Router();

// Save game score and record attendance
router.post('/save-score', authenticateToken, async (req, res) => {
    const { score } = req.body;

    try {
        const pool = await poolPromise;
        const userId = req.user.id;
        const date = new Date();

        // Save the score
        await pool.request()
            .input('userId', userId)
            .input('score', score)
            .input('date', date)
            .query('INSERT INTO Scores (userId, score, date) VALUES (@userId, @score, @date)');

        // Check if attendance is already recorded for today
        const existingAttendance = await pool.request()
            .input('userId', userId)
            .input('date', date.toISOString().split('T')[0]) // Check based on the date, ignoring time
            .query('SELECT * FROM Attendance WHERE userId = @userId AND CAST(attendanceDate AS DATE) = @date');

        if (existingAttendance.recordset.length === 0) {
            // Insert new attendance record
            await pool.request()
                .input('userId', userId)
                .input('attendanceDate', date)
                .query('INSERT INTO Attendance (userId, attendanceDate) VALUES (@userId, @attendanceDate)');
        }

        res.json({ message: 'Score and attendance recorded successfully' });
    } catch (err) {
        console.error('Database error:', err);
        res.status(500).json({ error: 'Database error occurred!' });
    }
});

// Get user's past scores
router.get('/my-scores', authenticateToken, async (req, res) => {
    try {
        const pool = await poolPromise;
        const result = await pool.request()
            .input('userId', req.user.id)
            .query('SELECT score, date FROM Scores WHERE userId = @userId ORDER BY date DESC');

        res.json(result.recordset);
    } catch (err) {
        console.error('Database error:', err);
        res.status(500).json({ error: 'Database error occurred!' });
    }
});

// Get all users' scores (for teacher/admin)
router.get('/scores', authenticateToken, async (req, res) => {
    try {
        const pool = await poolPromise;
        const result = await pool.request()
            .query('SELECT Users.id as studentId, Users.username, Scores.score, Scores.date FROM Scores INNER JOIN Users ON Scores.userId = Users.id ORDER BY Scores.date DESC');

        res.json(result.recordset);
    } catch (err) {
        console.error('Database error:', err);
        res.status(500).json({ error: 'Database error occurred!' });
    }
});

module.exports = router;
