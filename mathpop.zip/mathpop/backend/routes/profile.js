const express = require('express');
const bcrypt = require('bcryptjs');
const { poolPromise } = require('../config/db');
const authenticateToken = require('../middlewares/auth');

const router = express.Router();

// Get user profile
router.get('/', authenticateToken, async (req, res) => {
    try {
        const pool = await poolPromise;
        const result = await pool.request()
            .input('id', req.user.id)
            .query('SELECT id, username, role FROM Users WHERE id = @id');

        if (result.recordset.length === 0) {
            return res.status(404).json({ error: 'User not found' });
        }

        res.json(result.recordset[0]);
    } catch (err) {
        res.status(500).json({ error: 'Database error occurred!' });
    }
});

// Update user profile
router.put('/', authenticateToken, async (req, res) => {
    const { username, password } = req.body;
    try {
        const pool = await poolPromise;

        // If the user wants to update their password, hash it
        let hashedPassword;
        if (password) {
            hashedPassword = await bcrypt.hash(password, 10);
        }

        // Update the user's profile
        await pool.request()
            .input('id', req.user.id)
            .input('username', username)
            .input('password', hashedPassword)
            .query(`
                UPDATE Users 
                SET 
                    username = @username,
                    password = COALESCE(@password, password) 
                WHERE id = @id
            `);

        res.json({ message: 'Profile updated successfully' });
    } catch (err) {
        res.status(500).json({ error: 'Database error occurred!' });
    }
});

module.exports = router;
