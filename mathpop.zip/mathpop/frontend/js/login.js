// login.js

document.addEventListener('DOMContentLoaded', function () {
    const loginForm = document.getElementById('loginForm');

    loginForm.addEventListener('submit', async function (e) {
        e.preventDefault();

        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        try {
            const response = await fetch('/api/auth/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username, password }),
            });

            const data = await response.json();

            if (response.ok) {
                localStorage.setItem('token', data.token);
                alert('Login successful! Redirecting...');

                // Decode JWT to get the role
                const payload = JSON.parse(atob(data.token.split('.')[1]));
                const role = payload.role;

                if (role === 'teacher') {
                    window.location.href = '/teacher-dashboard.html';
                } else if (role === 'student') {
                    window.location.href = '/student-dashboard.html';
                } else {
                    alert('Unknown role. Redirecting to login.');
                    window.location.href = '/login.html';
                }
            } else {
                throw new Error(data.error || 'Login failed');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Login failed. Please check your credentials and try again.');
        }
    });
});
