document.addEventListener('DOMContentLoaded', function () {
    const token = localStorage.getItem('token');

    if (!token) {
        alert('You need to log in first.');
        window.location.href = '/login.html';
        return;
    }

    const editProfileButton = document.getElementById('editProfileButton');
    const editProfileCard = document.getElementById('editProfileCard');
    const editProfileForm = document.getElementById('editProfileForm');
    const playGameButton = document.getElementById('playGameButton');
    const logoutButton = document.getElementById('logoutButton');

    if (editProfileButton) {
        editProfileButton.addEventListener('click', function () {
            if (editProfileCard) {
                editProfileCard.classList.toggle('d-none');
            }
        });
    }

    if (editProfileForm) {
        editProfileForm.addEventListener('submit', function (e) {
            e.preventDefault();
            updateProfile(token);
        });
    }

    if (playGameButton) {
        playGameButton.addEventListener('click', function () {
            window.location.href = '/game';
        });
    }

    if (logoutButton) {
        logoutButton.addEventListener('click', function () {
            localStorage.removeItem('token');
            window.location.href = '/login.html';
        });
    }

    loadProfile(token);
    loadScores(token);
});

async function loadProfile(token) {
    try {
        const response = await fetch('/api/profile', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.ok) {
            const data = await response.json();
            const profileUsername = document.getElementById('profileUsername');
            const profilePic = document.getElementById('profilePic');
            const initialLetter = data.username.charAt(0).toUpperCase();

            if (profileUsername) {
                profileUsername.textContent = data.username;
            }

            if (profilePic) {
                profilePic.textContent = initialLetter;
            }
        } else {
            throw new Error('Failed to load profile.');
        }
    } catch (error) {
        console.error(error);
        alert('Error loading profile. Please try again.');
    }
}


async function updateProfile(token) {
    const username = document.getElementById('editUsername')?.value;
    const password = document.getElementById('editPassword')?.value;

    try {
        const response = await fetch('/api/profile', {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ username, password })
        });

        if (response.ok) {
            alert('Profile updated successfully.');
            document.getElementById('editProfileCard')?.classList.add('d-none');
            loadProfile(token);
        } else {
            throw new Error('Failed to update profile.');
        }
    } catch (error) {
        console.error(error);
        alert('Error updating profile. Please try again.');
    }
}

async function loadScores(token) {
    try {
        const response = await fetch('/api/game/my-scores', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.ok) {
            const scores = await response.json();
            const scoreList = document.getElementById('scoreList');
            if (scoreList) {
                scoreList.innerHTML = '';

                scores.forEach(score => {
                    const row = document.createElement('tr');

                    const scoreCell = document.createElement('td');
                    scoreCell.textContent = score.score;
                    row.appendChild(scoreCell);

                    const dateCell = document.createElement('td');
                    const date = new Date(score.date);
                    dateCell.textContent = date.toLocaleString();
                    row.appendChild(dateCell);

                    scoreList.appendChild(row);
                });
            }
        } else {
            throw new Error('Failed to load scores.');
        }
    } catch (error) {
        console.error(error);
        alert('Error loading scores. Please try again.');
    }
}

document.addEventListener('DOMContentLoaded', function () {
    const profileUsername = document.getElementById('profileUsername');
    const username = localStorage.getItem('username') || 'Username';
    profileUsername.textContent = username;

    const profilePopup = document.getElementById('profilePopup');
    const scoresPopup = document.getElementById('scoresPopup');

    document.querySelector('.profile-container').addEventListener('click', function () {
        profilePopup.style.display = 'block';
    });

    document.getElementById('showScoresButton').addEventListener('click', function () {
        scoresPopup.style.display = 'block';
    });

    document.getElementById('closeProfilePopup').addEventListener('click', function () {
        profilePopup.style.display = 'none';
    });

    document.getElementById('closeScoresPopup').addEventListener('click', function () {
        scoresPopup.style.display = 'none';
    });
});
