document.addEventListener('DOMContentLoaded', function () {
    const token = localStorage.getItem('token');

    if (!token) {
        alert('You need to log in first.');
        window.location.href = '/login.html';
        return;
    }

    // Event Listeners for Sidebar
    const menuToggle = document.getElementById('menu-toggle');
    const wrapper = document.getElementById('wrapper');
    menuToggle.addEventListener('click', function (e) {
        e.preventDefault();
        wrapper.classList.toggle('toggled');
    });

    const tabs = document.querySelectorAll('#sidebar-wrapper .list-group-item');
    const sections = document.querySelectorAll('.content-section');
    tabs.forEach(tab => {
        tab.addEventListener('click', function (e) {
            e.preventDefault();
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');

            const sectionId = tab.id.replace('Tab', 'Section');
            showSection(sectionId);
        });
    });

    function showSection(sectionId) {
        sections.forEach(section => {
            if (section.id === sectionId) {
                section.classList.remove('d-none');
            } else {
                section.classList.add('d-none');
            }
        });
    }

    // Initial Data Load
    loadProfile(token);
    loadUsers(token);
    loadScores(token);
    loadAttendance(token);

    // Profile Section Events
    document.getElementById('editProfileButton').addEventListener('click', function () {
        document.getElementById('editProfileCard').classList.toggle('d-none');
    });

    document.getElementById('cancelEditProfile').addEventListener('click', function () {
        document.getElementById('editProfileCard').classList.add('d-none');
    });

    document.getElementById('editProfileForm').addEventListener('submit', function (e) {
        e.preventDefault();
        updateProfile(token);
    });

    // User Management Events
    document.getElementById('addUserButton').addEventListener('click', function () {
        $('#addUserModal').modal('show');
    });

    document.getElementById('addUserForm').addEventListener('submit', function (e) {
        e.preventDefault();
        addUser(token);
    });

    document.getElementById('editUserForm').addEventListener('submit', function (e) {
        e.preventDefault();
        updateUser(token);
    });

    // Play Game Event
    document.getElementById('playGameButton').addEventListener('click', function () {
        window.location.href = '/game';
    });

    // Logout Event
    document.getElementById('logoutButton').addEventListener('click', function () {
        localStorage.removeItem('token');
        window.location.href = '/login.html';
    });
});

// Load Profile Information
async function loadProfile(token) {
    try {
        const response = await fetch('/api/profile', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.ok) {
            const data = await response.json();
            const username = data.username;
            document.getElementById('profileUsername').textContent = username;
            document.getElementById('profileRole').textContent = data.role;
            document.getElementById('editUsername').value = username;

            // Set the initial letter of the username in the profile picture
            document.getElementById('profilePic').textContent = username.charAt(0).toUpperCase();
        } else {
            throw new Error('Failed to load profile.');
        }
    } catch (error) {
        console.error(error);
        alert('Error loading profile. Please try again.');
    }
}


// Update Profile Information
async function updateProfile(token) {
    const username = document.getElementById('editUsername').value;
    const password = document.getElementById('editPassword').value;

    try {
        const response = await fetch('/api/profile', {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ username, password })
        });

        if (response.ok) {
            alert('Profile updated successfully.');
            document.getElementById('editProfileCard').classList.add('d-none');
            loadProfile(token);
        } else {
            throw new Error('Failed to update profile.');
        }
    } catch (error) {
        console.error(error);
        alert('Error updating profile. Please try again.');
    }
}

// Load Users
async function loadUsers(token) {
    try {
        const response = await fetch('/api/users', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.ok) {
            const users = await response.json();
            const userList = document.getElementById('userList');
            userList.innerHTML = '';

            users.forEach(user => {
                const row = document.createElement('tr');

                const usernameCell = document.createElement('td');
                usernameCell.textContent = user.username;
                row.appendChild(usernameCell);

                const roleCell = document.createElement('td');
                roleCell.textContent = user.role;
                row.appendChild(roleCell);

                const actionsCell = document.createElement('td');
                const editButton = document.createElement('button');
                editButton.classList.add('btn', 'btn-primary', 'btn-sm', 'mr-2');
                editButton.textContent = 'Edit';
                editButton.addEventListener('click', function () {
                    loadUserForEdit(user);
                });
                actionsCell.appendChild(editButton);

                const deleteButton = document.createElement('button');
                deleteButton.classList.add('btn', 'btn-danger', 'btn-sm');
                deleteButton.textContent = 'Delete';
                deleteButton.addEventListener('click', function () {
                    deleteUser(token, user.id);
                });
                actionsCell.appendChild(deleteButton);
                row.appendChild(actionsCell);

                userList.appendChild(row);
            });
        } else {
            throw new Error('Failed to load users.');
        }
    } catch (error) {
        console.error(error);
        alert('Error loading users. Please try again.');
    }
}

// Load User Information for Editing
function loadUserForEdit(user) {
    document.getElementById('editUserId').value = user.id;
    document.getElementById('editUsername').value = user.username;
    document.getElementById('editPassword').value = '';
    document.getElementById('editRole').value = user.role;
    $('#editUserModal').modal('show');
}

// Update User Information
async function updateUser(token) {
    const userId = document.getElementById('editUserId').value;
    const username = document.getElementById('editUsername').value;
    const password = document.getElementById('editPassword').value;
    const role = document.getElementById('editRole').value;

    try {
        const response = await fetch(`/api/users/${userId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ username, password, role })
        });

        if (response.ok) {
            alert('User updated successfully.');
            $('#editUserModal').modal('hide');
            loadUsers(token);
        } else {
            throw new Error('Failed to update user.');
        }
    } catch (error) {
        console.error(error);
        alert('Error updating user. Please try again.');
    }
}

// Add New User
async function addUser(token) {
    const username = document.getElementById('newUsername').value;
    const password = document.getElementById('newPassword').value;
    const role = document.getElementById('newRole').value;

    try {
        const response = await fetch('/api/users', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ username, password, role })
        });

        if (response.ok) {
            $('#addUserModal').modal('hide');
            document.getElementById('addUserForm').reset();
            alert('User added successfully.');
            loadUsers(token);
        } else {
            throw new Error('Failed to add user.');
        }
    } catch (error) {
        console.error(error);
        alert('Error adding user. Please try again.');
    }
}

// Delete User
async function deleteUser(token, userId) {
    if (!confirm('Are you sure you want to delete this user?')) return;

    try {
        const response = await fetch(`/api/users/${userId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.ok) {
            alert('User deleted successfully.');
            loadUsers(token);
        } else {
            throw new Error('Failed to delete user.');
        }
    } catch (error) {
        console.error(error);
        alert('Error deleting user. Please try again.');
    }
}

// Load Student Scores
// Load Student Scores
async function loadScores(token) {
    try {
        const response = await fetch('/api/game/scores', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.ok) {
            const scores = await response.json();
            const scoreList = document.getElementById('scoreList');
            scoreList.innerHTML = '';

            scores.forEach(score => {
                const row = document.createElement('tr');

                const usernameCell = document.createElement('td');
                usernameCell.textContent = score.username;
                row.appendChild(usernameCell);

                const scoreCell = document.createElement('td');
                scoreCell.textContent = score.score;
                row.appendChild(scoreCell);

                const dateCell = document.createElement('td');
                const date = new Date(score.date);

                // If the date is valid, format it
                if (!isNaN(date)) {
                    dateCell.textContent = date.toLocaleString(); // You can customize the format here
                } else {
                    dateCell.textContent = 'Invalid Date';
                }

                row.appendChild(dateCell);

                scoreList.appendChild(row);
            });
        } else {
            throw new Error('Failed to load scores.');
        }
    } catch (error) {
        console.error(error);
        alert('Error loading scores. Please try again.');
    }
}

// Load Attendance Records
async function loadAttendance(token) {
    try {
        const response = await fetch('/api/attendance', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.ok) {
            const attendanceRecords = await response.json();
            const attendanceList = document.getElementById('attendanceList');
            attendanceList.innerHTML = '';

            attendanceRecords.forEach(record => {
                const row = document.createElement('tr');

                const usernameCell = document.createElement('td');
                usernameCell.textContent = record.username;
                row.appendChild(usernameCell);

                const dateCell = document.createElement('td');
                const date = new Date(record.attendanceDate);
                dateCell.textContent = date.toLocaleString();
                row.appendChild(dateCell);

                attendanceList.appendChild(row);
            });
        } else {
            throw new Error('Failed to load attendance records.');
        }
    } catch (error) {
        console.error(error);
        alert('Error loading attendance records. Please try again.');
    }
}
